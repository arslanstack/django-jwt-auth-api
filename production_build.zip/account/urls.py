from django.urls import path, include
from account.views import UserRegistrationView, UserLoginView, UserProfileView, UserRefreshView, UserChangePasswordView, SendPasswordResetEmailView, UserPasswordResetView
from . import views

urlpatterns = [
    path("", views.home),
    path('api/user/register/', UserRegistrationView.as_view(), name='register'),
    path('api/user/login/', UserLoginView.as_view(), name='login'),
    path('api/user/me/', UserProfileView.as_view(), name='me'),
    path('api/user/refresh/', UserRefreshView.as_view(), name='refresh'),
    path('api/user/changepassword/', UserChangePasswordView.as_view(), name='changepassword'),
    path('api/user/send-reset-password-email/', SendPasswordResetEmailView.as_view(),
         name='send-reset-password-email'),
    path('api/user/reset-password/<uid>/<token>/',
         UserPasswordResetView.as_view(), name='reset-password'),

]
